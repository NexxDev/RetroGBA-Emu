package dev.retrogba.android

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import dev.retrogba.android.core.GbaCore
import dev.retrogba.android.core.GbaCoreStatus
import dev.retrogba.android.files.RomInfo
import dev.retrogba.android.files.RomInspector
import dev.retrogba.android.render.GameSurface

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var surface: GameSurface
    private lateinit var core: GbaCore
    private var selectedRom: Uri? = null
    private val openRomCode = 1201
    private val openBiosCode = 1202
    private var gamepadConnected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        core = GbaCore()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(0xFF10151D.toInt())
        }
        val title = TextView(this).apply {
            text = "RETROGBA"
            textSize = 22f
            setTextColor(0xFFF4F7FB.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        status = TextView(this).apply {
            text = "GBA · Selecciona una ROM. El núcleo real debe integrarse antes de jugar."
            textSize = 12f
            setTextColor(0xFFB8C4D4.toInt())
            setPadding(0, 5, 0, 8)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(actionButton("Abrir ROM") { pickFile(openRomCode) }, weighted())
        top.addView(actionButton("Elegir BIOS") { pickFile(openBiosCode) }, weighted())
        top.addView(actionButton("Guardar estado") { showCoreMessage(core.saveState()) }, weighted())
        top.addView(actionButton("Cargar estado") { showCoreMessage(core.loadState()) }, weighted())

        surface = GameSurface(this)
        root.addView(title)
        root.addView(status)
        root.addView(top)
        root.addView(surface, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val pad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row1.addView(padButton("↑", "UP"))
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row2.addView(padButton("←", "LEFT"))
        row2.addView(padButton("↓", "DOWN"))
        row2.addView(padButton("→", "RIGHT"))
        pad.addView(row1)
        pad.addView(row2)
        controls.addView(pad, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val speedText = TextView(this).apply {
            text = "Velocidad / avance rápido"
            setTextColor(0xFFE3EAF3.toInt())
            textSize = 11f
        }
        val speed = SeekBar(this).apply {
            max = 300
            progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    core.setSpeed((p / 100f).coerceIn(0.5f, 4f))
                    status.text = "Velocidad seleccionada: ${(p / 100f).coerceIn(0.5f, 4f)}x · ${core.status.message}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val volumeText = TextView(this).apply {
            text = "Volumen"
            setTextColor(0xFFE3EAF3.toInt())
            textSize = 11f
        }
        val volume = SeekBar(this).apply {
            max = 100
            progress = 75
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    core.setVolume(p / 100f)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        center.addView(speedText)
        center.addView(speed)
        center.addView(volumeText)
        center.addView(volume)
        controls.addView(center, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))

        val ab = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val ab1 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        ab1.addView(padButton("L", "L"))
        ab1.addView(padButton("R", "R"))
        val ab2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        ab2.addView(padButton("B", "B"))
        ab2.addView(padButton("A", "A"))
        val ab3 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        ab3.addView(padButton("SELECT", "SELECT"))
        ab3.addView(padButton("START", "START"))
        ab.addView(ab1)
        ab.addView(ab2)
        ab.addView(ab3)
        controls.addView(ab, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(controls)
        setContentView(root)
        refreshGamepadState()
    }

    private fun weighted() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 10f
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun padButton(label: String, button: String) = Button(this).apply {
        text = label
        textSize = 10f
        isAllCaps = false
        setOnTouchListener { _, event ->
            val pressed = event.action == MotionEvent.ACTION_DOWN ||
                event.action == MotionEvent.ACTION_POINTER_DOWN
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_UP ||
                event.action == MotionEvent.ACTION_CANCEL) {
                core.setButton(button, pressed)
            }
            true
        }
    }

    private fun pickFile(request: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream", "application/zip", "application/x-gba-rom"
            ))
        }
        startActivityForResult(i, request)
    }

    @Deprecated("Legacy callback used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {}
        when (requestCode) {
            openRomCode -> {
                selectedRom = uri
                val info = RomInspector.inspect(this, uri)
                status.text = when (info) {
                    is RomInfo.Gba -> "ROM GBA seleccionada: ${info.name} · ${info.sizeLabel}. ${core.status.message}"
                    is RomInfo.Zip -> "ZIP seleccionado: ${info.name}. Extrae o selecciona una ROM GBA interna."
                    is RomInfo.Unsupported -> "Archivo no reconocido: ${info.name}"
                }
                if (info is RomInfo.Gba) showCoreMessage(core.loadRom(uri))
            }
            openBiosCode -> {
                status.text = "BIOS seleccionada: ${uri.lastPathSegment}. La integración del núcleo determinará su uso."
                showCoreMessage(core.setBios(uri))
            }
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val key = when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> "UP"
            KeyEvent.KEYCODE_DPAD_DOWN -> "DOWN"
            KeyEvent.KEYCODE_DPAD_LEFT -> "LEFT"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "RIGHT"
            KeyEvent.KEYCODE_BUTTON_A -> "A"
            KeyEvent.KEYCODE_BUTTON_B -> "B"
            KeyEvent.KEYCODE_BUTTON_L1 -> "L"
            KeyEvent.KEYCODE_BUTTON_R1 -> "R"
            KeyEvent.KEYCODE_BUTTON_START -> "START"
            KeyEvent.KEYCODE_BUTTON_SELECT -> "SELECT"
            else -> null
        }
        if (key != null) {
            core.setButton(key, event.action == KeyEvent.ACTION_DOWN)
            refreshGamepadState()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun refreshGamepadState() {
        gamepadConnected = (0 until android.view.InputDevice.getDeviceIds().size).any { index ->
            val ids = android.view.InputDevice.getDeviceIds()
            val device = InputDevice.getDevice(ids[index])
            device != null && (device.sources and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD ||
                device.sources and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK)
        }
        // Visibility is a scaffold behavior; reliable hot-plug handling can be added with device listeners.
    }

    private fun showCoreMessage(result: GbaCoreStatus) {
        Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        core.close()
        super.onDestroy()
    }
}
