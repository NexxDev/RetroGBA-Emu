package dev.retrogba.android.files

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns

sealed class RomInfo {
    data class Gba(val name: String, val sizeLabel: String) : RomInfo()
    data class Zip(val name: String) : RomInfo()
    data class Unsupported(val name: String) : RomInfo()
}

object RomInspector {
    fun inspect(context: Context, uri: Uri): RomInfo {
        var name = uri.lastPathSegment ?: "archivo"
        var size = -1L
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val ext = name.substringAfterLast('.', "").lowercase()
        val sizeLabel = if (size >= 0) "${size / 1024} KB" else "tamaño desconocido"
        return when (ext) {
            "gba", "agb" -> RomInfo.Gba(name, sizeLabel)
            "zip" -> RomInfo.Zip(name)
            else -> RomInfo.Unsupported(name)
        }
    }
}
