package dev.retrogba.android.core

import android.net.Uri

data class GbaCoreStatus(val ready: Boolean, val message: String)

interface GbaEmulationBackend : AutoCloseable {
    fun loadRom(uri: Uri): GbaCoreStatus
    fun setBios(uri: Uri): GbaCoreStatus
    fun runFrame(): Boolean
    fun setButton(button: String, pressed: Boolean)
    fun setSpeed(multiplier: Float)
    fun setVolume(volume: Float)
    fun saveState(): GbaCoreStatus
    fun loadState(): GbaCoreStatus
    fun rewind(frameCount: Int): GbaCoreStatus
    override fun close()
}

/**
 * Explicit placeholder backend. A real GBA CPU/PPU/APU/timer/DMA/cartridge core
 * must be integrated before the app can execute commercial or homebrew ROMs.
 */
class GbaCore : GbaEmulationBackend {
    var status = GbaCoreStatus(false, "Núcleo GBA no integrado")
        private set
    private var speed = 1f
    private var volume = 0.75f
    private val pressed = mutableSetOf<String>()

    override fun loadRom(uri: Uri) = GbaCoreStatus(false,
        "ROM seleccionada; no se ejecuta hasta integrar un núcleo GBA real").also { status = it }
    override fun setBios(uri: Uri) = GbaCoreStatus(false,
        "BIOS registrada en la interfaz; aún no se valida ni se conecta a un núcleo").also { status = it }
    override fun runFrame() = false
    override fun setButton(button: String, pressed: Boolean) {
        if (pressed) this.pressed.add(button) else this.pressed.remove(button)
    }
    override fun setSpeed(multiplier: Float) { speed = multiplier.coerceIn(0.5f, 4f) }
    override fun setVolume(volume: Float) { this.volume = volume.coerceIn(0f, 1f) }
    override fun saveState() = GbaCoreStatus(false, "Save states requieren un núcleo GBA integrado")
    override fun loadState() = GbaCoreStatus(false, "Load states requieren un núcleo GBA integrado")
    override fun rewind(frameCount: Int) = GbaCoreStatus(false, "Rewind requiere snapshots del núcleo GBA")
    override fun close() {}
}
