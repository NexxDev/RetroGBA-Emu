# RetroGBA Android

Starter Android nativo en Kotlin para una aplicación centrada en Game Boy Advance.

## Estado funcional
- La app tiene una pantalla inicial, selector de ROM/BIOS con Android Storage Access Framework, botones táctiles y sliders de interfaz.
- Reconoce archivos `.gba` / `.agb` y detecta `.zip` como archivo comprimido.
- Incluye una interfaz de backend para conectar un núcleo real.
- **No ejecuta juegos todavía**: `GbaCore` es un backend provisional explícito, no un emulador.
- Save states, rewind, audio real, Fast Forward real, escaneo recursivo, extracción ZIP, editor visual de controles, filtros y hot-plug completo necesitan implementación/integración posterior.

## Compilar
Requiere JDK 17, Android SDK 35 y Gradle 8.9:
```bash
gradle assembleDebug
```
Salida: `app/build/outputs/apk/debug/app-debug.apk`

## Arquitectura
- `core/`: contrato de backend GBA y botones.
- `files/`: metadatos y detección de ROM/ZIP.
- `render/`: superficie de juego provisional.
- `MainActivity.kt`: interfaz y eventos de entrada.

## Núcleo real
Antes de anunciar compatibilidad, integra un núcleo GBA con licencia compatible, conserva sus avisos/licencia y conecta CPU, memoria, PPU, APU, DMA, temporizadores, cartuchos, SRAM/Flash/EEPROM y entrada. No incluyas BIOS ni ROMs con copyright en el repositorio.
